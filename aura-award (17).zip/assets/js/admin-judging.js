(function($) {
    'use strict';

    const AuraJudging = {
    basePath: auraAwardPaths.badgePreviewPath,
        init: function() {
    // Calculate initial totals based on saved scores
    let totalStars = 0;
    $('.score-display').each(function() {
        totalStars += parseInt($(this).text()) || 0;
    });
    
    $('#total-points').text(totalStars);
    const juryPoints = Math.round((totalStars * 100) / 60);
    $('#jury-points').text(juryPoints);
    
    // Update award level based on initial scores
    const awardLevel = this.determineAwardLevel(juryPoints);
    $('.award-level').text(`${awardLevel} Award`);
    $('.jury-points-display').text(`${juryPoints} Jury Points`);
    $('.medal-icon').attr('class', `medal-icon ${awardLevel.toLowerCase()}-medal`);

    // Initialize other components
    this.initializeStarRatings();
    this.initializeBadgePosition();
    this.initializeBadgePreview();
    this.bindEvents();
    this.updateScores();
},

        initializeBadgePosition: function() {
        const $badgeOverlay = $('.badge-overlay');
        $('#badge_position').on('change', function() {
            const position = $(this).val();
            $badgeOverlay.css({
                top: position.includes('top') ? '10px' : 'auto',
                bottom: position.includes('bottom') ? '10px' : 'auto',
                left: position.includes('left') ? '10px' : 'auto',
                right: position.includes('right') ? '10px' : 'auto'
            }).attr('data-position', position);
            
            const awardLevel = $('.award-level').text().toLowerCase().split(' ')[0];
            $badgeOverlay.css({
                'background-image': `url(${AuraJudging.basePath}${awardLevel}-badge-preview.png)`
            });
        });
    },

    initializeBadgePreview: function() {
        const $badgeOverlay = $('.badge-overlay');
        
        function updateBadgePreview() {
            const awardLevel = $('.award-level').text().toLowerCase().split(' ')[0];
            $badgeOverlay.css({
                'background-image': `url(${AuraJudging.basePath}${awardLevel}-badge-preview.png)`
            });
        }

        $(document).on('scoresUpdated', updateBadgePreview);
        
        // Initial preview
        $badgeOverlay.css({
    'background-image': `url(${this.basePath}default-badge-preview.png)`
        });
    },

        initializeStarRatings: function() {
            $('.star').on('click', function() {
                const $stars = $(this).parent().find('.star');
                const value = $(this).data('value');
                
                $stars.removeClass('active');
                $stars.slice(0, value).addClass('active');
                
                const $criteriaCard = $(this).closest('.criteria-card');
                $criteriaCard.find('.score-display').text(value);
                
                AuraJudging.updateScores();
            });
        },

        updateScores: function() {
            let totalStars = 0;
            const scores = {};

            $('.criteria-card').each(function() {
                const criteria = $(this).find('.star-rating').data('criteria');
                const score = parseInt($(this).find('.score-display').text()) || 0;
                scores[criteria] = score;
                totalStars += score;
            });
            
            const juryPoints = Math.round((totalStars * 100) / 60);
            const awardLevel = this.determineAwardLevel(juryPoints);
            
            $('#total-points').text(totalStars);
            $('#jury-points').text(juryPoints);
            $('.award-level').text(`${awardLevel} Award`);
            $('.jury-points-display').text(`${juryPoints} Jury Points`);
            $('.medal-icon').attr('class', `medal-icon ${awardLevel.toLowerCase()}-medal`);

            // Trigger event for badge preview update
            $(this).trigger('scoresUpdated');
        },

        determineAwardLevel: function(juryPoints) {
            if (juryPoints >= 91) return 'Platinum';
            if (juryPoints >= 71) return 'Gold';
            if (juryPoints >= 51) return 'Silver';
            if (juryPoints >= 30) return 'Bronze';
            return 'Participant';
        },

        saveJudgment: function(e) {
            e.preventDefault();
            
            const scores = {};
            let allScoresEntered = true;
            
            $('.criteria-card').each(function() {
                const criteria = $(this).find('.star-rating').data('criteria');
                const score = parseInt($(this).find('.score-display').text()) || 0;
                scores[criteria] = score;
                if (score === 0) allScoresEntered = false;
            });

            if (!allScoresEntered) {
                this.showNotification('Please rate all criteria before submitting.', 'error');
                return;
            }

            const $submitButton = $('.button-primary');
            $submitButton.prop('disabled', true).text('Saving...');

            $.ajax({
                url: auraAward.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'save_judgment',
                    nonce: auraAward.nonce,
                    entry_id: $('input[name="entry_id"]').val(),
                    scores: scores,
                    badge_position: $('#badge_position').val() // Add badge position to the data
                },
                success: (response) => {
                    if (response.success) {
                        this.showNotification('Judgment saved successfully!', 'success');
                        setTimeout(() => this.loadNextEntry(), 1500);
                    } else {
                        this.showNotification(response.data || 'Failed to save judgment.', 'error');
                        $submitButton.prop('disabled', false).text('Submit Judgment');
                    }
                },
                error: () => {
                    this.showNotification('Server error occurred.', 'error');
                    $submitButton.prop('disabled', false).text('Submit Judgment');
                }
            });
        },


        bindEvents: function() {
            $('#judging-form').on('submit', this.saveJudgment.bind(this));
            $('.skip-entry').on('click', this.loadNextEntry.bind(this));
        },

        showNotification: function(message, type) {
            const $notification = $('<div>')
                .addClass(`notification ${type}`)
                .text(message)
                .appendTo('body');
            
            setTimeout(() => {
                $notification.fadeOut(() => $notification.remove());
            }, 3000);
        },

        loadNextEntry: function() {
            location.reload();
        }
    };

    $(document).ready(function() {
        AuraJudging.init();
    });
})(jQuery);