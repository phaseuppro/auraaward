jQuery(document).ready(function($) {
    console.log('Aura Award form initialized');
    
    // Add progress bar HTML to the form
    $('.aura-submission-form form').append('<div class="upload-progress"><div class="progress-bar"></div></div>');
    
    $('.aura-submission-form form').on('submit', function(e) {
        e.preventDefault();
        console.log('Form submitted');
        
        var formData = new FormData(this);
        formData.append('action', 'submit_aura_entry');
        formData.append('nonce', auraAward.nonce);
        
        console.log('FormData contents:', {
            action: formData.get('action'),
            nonce: formData.get('nonce'),
            title: formData.get('title'),
            photo: formData.get('photo')
        });
        
        $.ajax({
            url: auraAward.ajaxUrl,
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            beforeSend: function() {
                console.log('Starting upload');
                $('.upload-progress').show();
            },
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener('progress', function(evt) {
                    if (evt.lengthComputable) {
                        var percentComplete = Math.round((evt.loaded / evt.total) * 100);
                        $('.progress-bar').width(percentComplete + '%');
                        console.log('Upload progress:', percentComplete + '%');
                    }
                }, false);
                return xhr;
            },
            success: function(response) {
                console.log('Upload response:', response);
                if (response.success) {
                    alert('Photo submitted successfully!');
                    location.reload();
                } else {
                    alert(response.data);
                }
            },
            error: function(xhr, status, error) {
                console.log('Upload error:', {
                    status: status,
                    error: error,
                    response: xhr.responseText
                });
                alert('Upload failed. Please check console for details.');
            }
        });
    });
});
