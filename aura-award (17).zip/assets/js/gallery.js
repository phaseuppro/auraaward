(function($) {
    'use strict';

    const AuraGallery = {
        init: function() {
            this.bindEvents();
        },

        bindEvents: function() {
            $('.award-filter').on('change', this.filterGallery);
            $('.gallery-item').on('click', this.showImageDetails);
        },

        filterGallery: function() {
            const selectedAward = $(this).val();
            
            $('.gallery-item').each(function() {
                if (selectedAward === 'all' || $(this).data('award') === selectedAward) {
                    $(this).fadeIn();
                } else {
                    $(this).fadeOut();
                }
            });
        },

        showImageDetails: function(e) {
            e.preventDefault();
            // Implement lightbox or modal display here
        }
    };

    $(document).ready(function() {
        AuraGallery.init();
    });
})(jQuery);
