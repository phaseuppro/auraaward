(function($) {
    'use strict';

    const AuraLightbox = {
        init: function() {
            this.createLightboxHTML();
            this.bindEvents();
        },

        createLightboxHTML: function() {
            const lightbox = `
                <div class="aura-lightbox">
                    <div class="lightbox-content">
                        <img src="" alt="">
                        <div class="score-details"></div>
                        <button class="close-lightbox">&times;</button>
                        <button class="prev-image">&lt;</button>
                        <button class="next-image">&gt;</button>
                    </div>
                </div>
            `;
            $('body').append(lightbox);
        },

        bindEvents: function() {
            $('.gallery-item').on('click', this.openLightbox);
            $('.close-lightbox').on('click', this.closeLightbox);
            $('.prev-image').on('click', this.prevImage);
            $('.next-image').on('click', this.nextImage);
            $(document).on('keyup', this.handleKeyboard);
        },

        openLightbox: function() {
            const $item = $(this);
            const imageUrl = $item.find('img').attr('src');
            const defaultScores = {
                light: 0,
                pose: 0,
                idea: 0,
                emotion: 0,
                materials: 0,
                colors: 0,
                jury_points: 0
            };
            const scoreData = $.extend({}, defaultScores, $item.data('scores'));
            
            $('.aura-lightbox img').attr('src', imageUrl);
            $('.score-details').html(AuraLightbox.formatScoreDetails(scoreData));
            $('.aura-lightbox').fadeIn();
            $item.addClass('active').siblings().removeClass('active');
        },

        formatScoreDetails: function(scores) {
            return `
                <div class="score-grid">
                    <div class="score-item">Light Quality: ${scores.light}/10</div>
                    <div class="score-item">Pose & Composition: ${scores.pose}/10</div>
                    <div class="score-item">Creative Concept: ${scores.idea}/10</div>
                    <div class="score-item">Emotional Impact: ${scores.emotion}/10</div>
                    <div class="score-item">Technical Quality: ${scores.materials}/10</div>
                    <div class="score-item">Color Harmony: ${scores.colors}/10</div>
                    <div class="total-score">Total Jury Points: ${scores.jury_points}</div>
                </div>
            `;
        },

        closeLightbox: function() {
            $('.aura-lightbox').fadeOut();
            $('.gallery-item').removeClass('active');
        },

        prevImage: function() {
            const currentItem = $('.gallery-item.active');
            const prevItem = currentItem.prev('.gallery-item');
            if (prevItem.length) {
                prevItem.trigger('click');
            }
        },

        nextImage: function() {
            const currentItem = $('.gallery-item.active');
            const nextItem = currentItem.next('.gallery-item');
            if (nextItem.length) {
                nextItem.trigger('click');
            }
        },

        handleKeyboard: function(e) {
            if ($('.aura-lightbox').is(':visible')) {
                switch(e.keyCode) {
                    case 27: // ESC
                        AuraLightbox.closeLightbox();
                        break;
                    case 37: // Left arrow
                        AuraLightbox.prevImage();
                        break;
                    case 39: // Right arrow
                        AuraLightbox.nextImage();
                        break;
                }
            }
        }
    };

    $(document).ready(function() {
        AuraLightbox.init();
    });
})(jQuery);
