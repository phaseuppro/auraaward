<?php
/*
Plugin Name: Aura Award
Plugin URI: https://your-website.com
Description: A WordPress plugin for photo contests with advanced judging capabilities
Version: 1.0
Author: Your Name
Author URI: https://your-website.com
*/

// Add these lines right after the opening PHP tag
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!defined('ABSPATH')) {
    exit;
}

define('AURA_AWARD_DEBUG', true);
define('AURA_AWARD_VERSION', '1.0');
define('AURA_AWARD_PATH', plugin_dir_path(__FILE__));
define('AURA_AWARD_URL', plugin_dir_url(__FILE__));

add_filter('big_image_size_threshold', function($threshold, $imagesize, $file, $attachment_id) {
    return 2048;
}, 10, 4);

// Debug function
function aura_award_debug($message, $data = null) {
    if (AURA_AWARD_DEBUG) {
        $log_message = '[Aura Award] ' . $message;
        if ($data) {
            $log_message .= ': ' . print_r($data, true);
        }
        error_log($log_message);
    }
}
class AuraAward {
    const DEBUG = true;
    private static $instance = null;
    private $tables_created = false;
     private $badge_processor;
    private $badge_settings;
    private $gallery_display;
    
    public static function init() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
    register_activation_hook(__FILE__, array($this, 'activate_plugin'));
    register_deactivation_hook(__FILE__, array($this, 'deactivate_plugin'));
    
    // Core initialization hooks
    add_action('init', array($this, 'initialize_plugin'));
    add_action('admin_init', array($this, 'check_database_tables'));
    add_action('admin_init', array($this, 'add_judging_capability'));
    
    // Admin hooks
    add_action('admin_menu', array($this, 'create_admin_menu'));
    add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
    add_action('admin_menu', array($this, 'add_submissions_menu'));
    
    // Frontend hooks
    add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
    
    // AJAX handlers
    add_action('wp_ajax_submit_aura_entry', array($this, 'handle_submission'));
    add_action('wp_ajax_save_judgment', array($this, 'save_judgment'));
}
// Add this new method to your class
public function activate_plugin() {
    // Create initial tables
    $this->create_database_tables();
    
    // Update database structure for new columns
    $db_handler = new AuraDBHandler();
    $db_handler->update_database_structure();
    
    flush_rewrite_rules();
}
public function enqueue_admin_scripts($hook) {
    error_log('Loading admin scripts for hook: ' . $hook);
    
    if (strpos($hook, 'aura-award') !== false) {
        // Existing styles
        wp_enqueue_style('aura-award-admin', AURA_AWARD_URL . 'assets/css/admin.css', array(), AURA_AWARD_VERSION);
        
        if (strpos($hook, 'judging') !== false) {
            wp_enqueue_style('aura-judging-admin', AURA_AWARD_URL . 'assets/css/admin-judging.css', [], '1.0.0');
        }
        if (strpos($hook, 'aura_badge_settings') !== false) {
            wp_enqueue_style('aura-badge-settings', AURA_AWARD_URL . 'assets/css/admin-badge-settings.css', array(), AURA_AWARD_VERSION);
        }
        
        // New styles
        wp_enqueue_style('aura-gallery', AURA_AWARD_URL . 'assets/css/gallery.css', array(), AURA_AWARD_VERSION);
        wp_enqueue_style('aura-lightbox', AURA_AWARD_URL . 'assets/css/lightbox.css', array(), AURA_AWARD_VERSION);
        
        // Scripts
        wp_enqueue_script('aura-award-judging', AURA_AWARD_URL . 'assets/js/admin-judging.js', array('jquery', 'jquery-ui-slider'), AURA_AWARD_VERSION, true);
        wp_enqueue_script('aura-gallery', AURA_AWARD_URL . 'assets/js/gallery.js', array('jquery'), AURA_AWARD_VERSION, true);
        wp_enqueue_script('aura-lightbox', AURA_AWARD_URL . 'assets/js/lightbox.js', array('jquery'), AURA_AWARD_VERSION, true);
    
        wp_localize_script('aura-award-judging', 'auraAward', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aura_award_judging')
        ));
        wp_localize_script('aura-award-judging', 'auraAwardPaths', array(
    'badgePreviewPath' => AURA_AWARD_URL . 'assets/badges/preview/'
));
    }
}




public function add_judging_capability() {
    $role = get_role('administrator');
    if ($role && !$role->has_cap('judge_entries')) {
        $role->add_cap('judge_entries');
    }
}


public function deactivate_plugin() {
    flush_rewrite_rules();
}

public function check_database_tables() {
    if (!$this->tables_created) {
        $this->create_database_tables();
    }
}

public function render_new_contest_page() {
    $this->handle_contest_submission();
    include AURA_AWARD_PATH . 'templates/admin/new-contest.php';
}

public function add_submissions_menu() {
    error_log('Adding submissions menu');
    
    add_submenu_page(
        'aura-award',         // Parent slug
        'Submissions',        // Page title
        'Submissions',        // Menu title
        'manage_options',     // Capability
        'aura-submissions',   // Menu slug
        array($this, 'render_submissions_page')
    );
    
    error_log('Submissions menu added');
}

public function render_submissions_page() {
    error_log('Starting render_submissions_page');
    
    require_once AURA_AWARD_PATH . 'includes/class-aura-submissions-list.php';
    $submissions_table = new Aura_Submissions_List();
    
    error_log('Table class loaded');
    
    $submissions_table->prepare_items();
    
    error_log('Items prepared');
    
    echo '<div class="wrap">';
    echo '<h1>Photo Submissions</h1>';
    echo '<div style="background: #fff; padding: 20px; margin-top: 20px;">';
    
    // Debug output
    error_log('About to display table');
    ob_start();
    $submissions_table->display();
    $table_output = ob_get_clean();
    error_log('Table HTML: ' . $table_output);
    
    echo $table_output;
    echo '</div>';
    echo '</div>';
    
    error_log('Page fully rendered');
}


public function render_judging_page() {
    global $wpdb;
    
    // Get all pending entries
    $entries = $wpdb->get_results("
    SELECT e.*, u.display_name,
           e.light_score, e.pose_score, e.idea_score, 
           e.emotion_score, e.materials_score, e.colors_score,
           e.total_score, e.jury_points, e.award_level 
    FROM {$wpdb->prefix}aura_entries e 
    LEFT JOIN {$wpdb->users} u ON e.user_id = u.ID 
    WHERE e.status = 'pending' 
    ORDER BY e.submission_date ASC
");
    
    // Get the specific entry for judging (first pending entry)
    $entry = !empty($entries) ? $entries[0] : null;
    
    include AURA_AWARD_PATH . 'templates/admin/judging-interface.php';
}

public function create_admin_menu() {
    // Add judging capability to administrators
    $role = get_role('administrator');
    $role->add_cap('judge_entries');

    add_menu_page(
        'Aura Award',
        'Aura Award',
        'manage_options',
        'aura-award',
        array($this, 'render_admin_page'),
        'dashicons-awards',
        30
    );

    add_submenu_page(
        'aura-award',
        'All Contests',
        'All Contests',
        'manage_options',
        'aura-award',
        array($this, 'render_admin_page')
    );

    add_submenu_page(
        'aura-award',
        'Add New Contest',
        'Add New Contest',
        'manage_options',
        'aura-new-contest',
        array($this, 'render_new_contest_page')
    );

    add_submenu_page(
        'aura-award',
        'Judging',
        'Judging',
        'judge_entries',  // Using the new capability
        'aura-award-judging',
        array($this, 'render_judging_page')
    );
}

public function enqueue_frontend_scripts() {
    wp_enqueue_style('aura-award-frontend', AURA_AWARD_URL . 'assets/css/frontend.css', array(), AURA_AWARD_VERSION);
    wp_enqueue_script('aura-award-frontend', AURA_AWARD_URL . 'assets/js/frontend.js', array('jquery'), AURA_AWARD_VERSION, true);
    
    wp_localize_script('aura-award-frontend', 'auraAward', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('aura_award_submission')
    ));
}

public function handle_contest_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contest_nonce'])) {
        check_admin_referer('create_contest', 'contest_nonce');
        
        global $wpdb;
        
        $contest_data = array(
            'title' => sanitize_text_field($_POST['contest_title']),
            'description' => wp_kses_post($_POST['contest_description']),
            'start_date' => sanitize_text_field($_POST['start_date']),
            'end_date' => sanitize_text_field($_POST['end_date']),
            'status' => sanitize_text_field($_POST['contest_status'])
        );
        
        $wpdb->insert($wpdb->prefix . 'aura_contests', $contest_data);
        $contest_id = $wpdb->insert_id;
        
        // Create a new page with shortcodes
        $page_content = '[aura_submission_form contest_id="' . $contest_id . '"]
[aura_gallery contest_id="' . $contest_id . '"]';
        
        $page = array(
            'post_title' => $contest_data['title'],
            'post_content' => $page_content,
            'post_status' => 'publish',
            'post_type' => 'page'
        );
        
        wp_insert_post($page);
        
        wp_redirect(admin_url('admin.php?page=aura-award&contest_created=1'));
        exit;
    }
}

public function handle_submission() {
    header('Content-Type: application/json');
    error_log('Submission started');
    
    if (!is_user_logged_in()) {
        error_log('User not logged in');
        wp_send_json_error('Please log in to submit entries.');
        return;
    }

    if (!check_ajax_referer('aura_award_submission', 'nonce', false)) {
        error_log('Nonce verification failed');
        wp_send_json_error('Security check failed');
        return;
    }

    error_log('POST data: ' . print_r($_POST, true));
    error_log('FILES data: ' . print_r($_FILES, true));
    check_ajax_referer('aura_award_submission', 'nonce');
    
    require_once AURA_AWARD_PATH . 'includes/class-aura-submission-handler.php';
    $submission_handler = new AuraSubmissionHandler();
    $result = $submission_handler->handle_submission();
    
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }
    
    wp_send_json_success([
        'message' => 'Entry submitted successfully',
        'entry_id' => $result
    ]);
}


public function save_judgment() {
    error_log('Received judgment data: ' . print_r($_POST, true));
    header('Content-Type: application/json');
    require_once AURA_AWARD_PATH . 'includes/class-aura-judging-system.php';
    
    check_ajax_referer('aura_award_judging', 'nonce');
    
    try {
        if (!current_user_can('judge_entries')) {
            throw new Exception('Insufficient permissions');
        }
        
        $judging_system = new AuraJudgingSystem();
        
        $entry_id = isset($_POST['entry_id']) ? intval($_POST['entry_id']) : 0;
        if (!$entry_id) {
            throw new Exception('Entry ID is required');
        }
        
        $scores = array(
            'light' => intval($_POST['scores']['light']),
            'pose' => intval($_POST['scores']['pose']),
            'idea' => intval($_POST['scores']['idea']),
            'emotion' => intval($_POST['scores']['emotion']),
            'materials' => intval($_POST['scores']['materials']),
            'colors' => intval($_POST['scores']['colors'])
        );
        
        $badge_position = sanitize_text_field($_POST['badge_position']);
        
        $result = $judging_system->process_judgment($entry_id, $scores, $badge_position);
        
        if (is_wp_error($result)) {
            throw new Exception($result->get_error_message());
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Judgment saved successfully',
            'data' => $result
        ]);
        
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
    
    exit;
}



public function initialize_plugin() {
    // Load required classes
    require_once AURA_AWARD_PATH . 'includes/class-aura-db-handler.php';
    require_once AURA_AWARD_PATH . 'includes/class-aura-contest-manager.php';
    require_once AURA_AWARD_PATH . 'includes/class-aura-user-dashboard.php';
    require_once AURA_AWARD_PATH . 'includes/class-aura-statistics.php';
    require_once AURA_AWARD_PATH . 'includes/class-aura-badge-processor.php';
    require_once AURA_AWARD_PATH . 'includes/class-aura-badge-settings.php';
    require_once AURA_AWARD_PATH . 'includes/class-aura-gallery-display.php';
    
    // Initialize database handler first
    $db_handler = AuraDBHandler::get_instance();
    
    // Initialize all components
    $this->badge_processor = AuraBadgeProcessor::get_instance();
    $this->badge_settings = AuraBadgeSettings::get_instance();
    $this->gallery_display = new AuraGalleryDisplay($db_handler);
    
    // Register all shortcodes
    add_shortcode('aura_submission_form', array($this, 'render_submission_form'));
    add_shortcode('aura_gallery', array($this->gallery_display, 'render_gallery'));
    add_shortcode('aura_user_dashboard', array($this, 'render_user_dashboard'));
    add_shortcode('aura_judged_gallery', array($this->gallery_display, 'render_gallery'));
}

public function render_admin_page() {
    $contest_manager = new AuraContestManager();
    $statistics = new AuraStatistics();
    
    // Get all contests
    global $wpdb;
    $contests = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}aura_contests ORDER BY created_at DESC");
    
    $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'overview';
    
    switch ($active_tab) {
        case 'judging':
            include AURA_AWARD_PATH . 'templates/admin/judging-interface.php';
            break;
        case 'reports':
            include AURA_AWARD_PATH . 'templates/admin/contest-report.php';
            break;
        default:
            include AURA_AWARD_PATH . 'templates/admin/contests-overview.php';
            break;
    }
}


public function render_submission_form($atts) {
    if (!is_user_logged_in()) {
        return '<p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to submit your entry.</p>';
    }
    
    $contest_id = isset($atts['contest_id']) ? intval($atts['contest_id']) : 0;
    ob_start();
    include AURA_AWARD_PATH . 'templates/frontend/submission-form.php';
    return ob_get_clean();
}



public function render_gallery($atts) {
    $contest_id = isset($atts['contest_id']) ? intval($atts['contest_id']) : 0;
    ob_start();
    return AuraGalleryDisplay::get_instance()->render_gallery($atts);
    return ob_get_clean();
}

private function render_user_dashboard() {
    if (!is_user_logged_in()) {
        return '<p>Please log in to view your dashboard.</p>';
    }
    
    $dashboard = new AuraUserDashboard();
    return $dashboard->render_dashboard();
}

    private function create_database_tables() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    
    $entries_table = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}aura_entries (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        contest_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        title varchar(255) NOT NULL,
        photographer_name varchar(100) NOT NULL,
        photo_url varchar(255) NOT NULL,
        processed_photo_url varchar(255) DEFAULT NULL,
        attachment_id bigint(20) DEFAULT NULL,
        submission_date datetime DEFAULT CURRENT_TIMESTAMP,
        status varchar(20) DEFAULT 'pending',
        light_score int NOT NULL DEFAULT 0,
        pose_score int NOT NULL DEFAULT 0,
        idea_score int NOT NULL DEFAULT 0,
        emotion_score int NOT NULL DEFAULT 0,
        materials_score int NOT NULL DEFAULT 0,
        colors_score int NOT NULL DEFAULT 0,
        total_score int NOT NULL DEFAULT 0,
        jury_points int NOT NULL DEFAULT 0,
        award_level varchar(20) DEFAULT NULL,
        badge_position varchar(20) DEFAULT 'top-right',
        judged_date datetime DEFAULT NULL,
        PRIMARY KEY (id),
        KEY contest_id (contest_id),
        KEY user_id (user_id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($entries_table);
}



function enqueue_judging_scripts() {
    wp_localize_script('aura-judging-script', 'auraAward', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('aura_award_judging'),
        'pluginUrl' => AURA_AWARD_URL,
        'badges' => array(
            'preview' => array(
                'default' => AURA_AWARD_URL . 'assets/badges/preview/default-badge-preview.png',
                'platinum' => AURA_AWARD_URL . 'assets/badges/preview/platinum-badge-preview.png',
                'gold' => AURA_AWARD_URL . 'assets/badges/preview/gold-badge-preview.png',
                'silver' => AURA_AWARD_URL . 'assets/badges/preview/silver-badge-preview.png',
                'bronze' => AURA_AWARD_URL . 'assets/badges/preview/bronze-badge-preview.png',
                'participant' => AURA_AWARD_URL . 'assets/badges/preview/participant-badge-preview.png'
            )
        )
    ));
}

}

// Initialize the plugin
function aura_award_init() {
    return AuraAward::init();
}

add_action('plugins_loaded', 'aura_award_init', 20);

// Register and enqueue all assets
add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('aura-gallery', AURA_AWARD_URL . 'assets/css/gallery.css');
    wp_enqueue_style('aura-lightbox', AURA_AWARD_URL . 'assets/css/lightbox.css');
    wp_enqueue_script('aura-gallery', AURA_AWARD_URL . 'assets/js/gallery.js', array('jquery'), null, true);
    wp_enqueue_script('aura-lightbox', AURA_AWARD_URL . 'assets/js/lightbox.js', array('jquery'), null, true);
});



