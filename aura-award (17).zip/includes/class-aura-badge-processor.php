<?php

class AuraBadgeProcessor {
    private static $instance = null;
    private $badge_path;
    private $position_options;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        $this->badge_path = AURA_AWARD_PATH . 'assets/badges/';
        $this->position_options = [
            'top-left' => ['x' => 20, 'y' => 20],
            'top-right' => ['x' => 'right', 'y' => 20],
            'bottom-left' => ['x' => 20, 'y' => 'bottom'],
            'bottom-right' => ['x' => 'right', 'y' => 'bottom']
        ];
        add_filter('upload_dir', array($this, 'modify_upload_dir'));
        $this->init();
    }

public function init() {
    add_action('admin_init', array($this, 'register_settings'));
    add_action('admin_menu', array($this, 'add_settings_page'));
}

public function register_settings() {
    register_setting('aura_badge_options', 'aura_badge_settings', array(
        'type' => 'array',
        'sanitize_callback' => array($this, 'sanitize_settings')
    ));
}

public function add_settings_page() {
    add_submenu_page(
        'aura-award',
        'Badge Settings',
        'Badge Settings',
        'manage_options',
        'aura-badge-settings',
        array($this, 'render_settings_page')
    );
}

public function render_settings_page() {
    include AURA_AWARD_PATH . 'templates/admin/badge-settings.php';
}

public function sanitize_settings($input) {
    $sanitized = array();
    
    $sanitized['size'] = isset($input['size']) ? sanitize_text_field($input['size']) : 'medium';
    $sanitized['show_scores'] = isset($input['show_scores']) ? 1 : 0;
    $sanitized['show_total'] = isset($input['show_total']) ? 1 : 0;
    $sanitized['style'] = isset($input['style']) ? sanitize_text_field($input['style']) : 'classic';
    
    return $sanitized;
}

    public function process_judged_image($entry_id, $badge_position) {
    error_log('Starting badge processing for entry: ' . $entry_id);
    global $wpdb;
    
    $entry = $wpdb->get_row($wpdb->prepare("
        SELECT e.*, u.display_name, u.user_nicename as photographer_name 
        FROM {$wpdb->prefix}aura_entries e 
        LEFT JOIN {$wpdb->users} u ON e.user_id = u.ID 
        WHERE e.id = %d", 
        $entry_id
    ));

    error_log('Entry data: ' . print_r($entry, true));

    if (!$entry) {
        error_log('Entry not found for ID: ' . $entry_id);
        return new WP_Error('invalid_entry', 'Entry not found');
    }

    error_log('Loading source image from: ' . $entry->photo_url);
    $source = imagecreatefromjpeg($entry->photo_url);
    
    $badge_file = $this->badge_path . $entry->award_level . '.png';
    error_log('Loading badge from: ' . $badge_file);

    
    // Verify badge file exists
    if (!file_exists($badge_file)) {
        error_log('Badge file not found: ' . $badge_file);
        return new WP_Error('badge_missing', 'Badge file not found');
    }
    
    $badge = imagecreatefrompng($badge_file);
    if (!$badge) {
        error_log('Failed to create badge image from: ' . $badge_file);
        return new WP_Error('badge_creation_failed', 'Failed to create badge image');
    }
    // Add badge with specified position
    $this->add_badge($source, $badge, $badge_position);
    
    // Add scoring details with photographer name
    $this->add_scoring_details($source, $entry);
    
    // Save processed image
    $filename = sanitize_file_name(
        $entry->award_level . '-' . 
        ($entry->photographer_name ?: $entry->display_name) . '-' . 
        date('Y-m-d') . '.jpg'
    );

    $upload_dir = wp_upload_dir();
    $save_path = $upload_dir['path'] . '/' . $filename;
    
    imagejpeg($source, $save_path, 90);
    
    // Add to media library with complete metadata
    $attachment = array(
        'post_mime_type' => 'image/jpeg',
        'post_title' => $entry->title,
        'post_content' => '',
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $save_path);
    
    update_post_meta($attach_id, '_aura_judging_data', array(
        'entry_id' => $entry_id,
        'award_level' => $entry->award_level,
        'jury_points' => $entry->jury_points,
        'photographer_name' => $entry->photographer_name ?: $entry->display_name,
        'badge_position' => $badge_position,
        'scores' => array(
            'light' => $entry->light_score,
            'pose' => $entry->pose_score,
            'idea' => $entry->idea_score,
            'emotion' => $entry->emotion_score,
            'materials' => $entry->materials_score,
            'colors' => $entry->colors_score
        )
    ));

    return $attach_id;
}
    private function add_scoring_details($image, $entry) {
        $font_path = AURA_AWARD_PATH . 'assets/fonts/OpenSans-Bold.ttf';
        $font_size = 24;
        $color = imagecolorallocate($image, 255, 255, 255);
        $shadow = imagecolorallocate($image, 0, 0, 0);
        
        $y = 400;
        $x = 50;
        
        $criteria = array(
            'Light Quality' => $entry->light_score,
            'Pose & Composition' => $entry->pose_score,
            'Creative Concept' => $entry->idea_score,
            'Emotional Impact' => $entry->emotion_score,
            'Technical Quality' => $entry->materials_score,
            'Color Harmony' => $entry->colors_score
        );

        foreach ($criteria as $name => $score) {
            $text = sprintf("%s: %d/10", $name, $score);
            imagettftext($image, $font_size, 0, $x+2, $y+2, $shadow, $font_path, $text);
            imagettftext($image, $font_size, 0, $x, $y, $color, $font_path, $text);
            $y += 40;
        }

        $total_text = sprintf("Total Jury Points: %d/100", $entry->jury_points);
        $y += 20;
        imagettftext($image, $font_size+4, 0, $x+2, $y+2, $shadow, $font_path, $total_text);
        imagettftext($image, $font_size+4, 0, $x, $y, $color, $font_path, $total_text);
    }

    private function add_badge($source, $badge, $position) {
        $coordinates = $this->calculate_position(
            $position, 
            imagesx($source), 
            imagesy($source), 
            350, 
            350
        );
        
        imagecopy(
            $source,
            $badge,
            $coordinates['x'],
            $coordinates['y'],
            0,
            0,
            350,
            350
        );
    }

    private function calculate_position($position, $img_width, $img_height, $badge_width, $badge_height) {
        $pos = $this->position_options[$position];
        $x = $pos['x'] === 'right' ? ($img_width - $badge_width - 20) : $pos['x'];
        $y = $pos['y'] === 'bottom' ? ($img_height - $badge_height - 20) : $pos['y'];
        
        return ['x' => $x, 'y' => $y];
    }

    public function modify_upload_dir($dirs) {
        $dirs['subdir'] = '/aura-judged/' . date('Y');
        $dirs['path'] = $dirs['basedir'] . $dirs['subdir'];
        $dirs['url'] = $dirs['baseurl'] . $dirs['subdir'];
        return $dirs;
    }
}
