<?php

class AuraBadgeSettings {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_menu', array($this, 'add_settings_page'));
    }

    public function register_settings() {
        register_setting('aura_badge_options', 'aura_badge_settings');

        add_settings_section(
            'aura_badge_main',
            'Badge Display Settings',
            null,
            'aura_badge_settings'
        );

add_settings_field(
        'badge_size',
        'Badge Size',
        array($this, 'render_size_field'),
        'aura_badge_settings',
        'aura_badge_main'
    );

    add_settings_field(
        'badge_style',
        'Badge Style',
        array($this, 'render_style_field'),
        'aura_badge_settings',
        'aura_badge_main'
    );

        add_settings_field(
            'badge_position',
            'Default Badge Position',
            array($this, 'render_position_field'),
            'aura_badge_settings',
            'aura_badge_main'
        );

        add_settings_field(
            'score_display',
            'Score Display Options',
            array($this, 'render_score_options'),
            'aura_badge_settings',
            'aura_badge_main'
        );
    }

    public function render_position_field() {
        $options = get_option('aura_badge_settings');
        $position = isset($options['badge_position']) ? $options['badge_position'] : 'top-right';
        ?>
        <select name="aura_badge_settings[badge_position]">
            <option value="top-left" <?php selected($position, 'top-left'); ?>>Top Left</option>
            <option value="top-right" <?php selected($position, 'top-right'); ?>>Top Right</option>
            <option value="bottom-left" <?php selected($position, 'bottom-left'); ?>>Bottom Left</option>
            <option value="bottom-right" <?php selected($position, 'bottom-right'); ?>>Bottom Right</option>
        </select>
        <?php
    }

    public function render_score_options() {
        $options = get_option('aura_badge_settings');
        $display = isset($options['score_display']) ? $options['score_display'] : array();
        ?>
        <label>
            <input type="checkbox" name="aura_badge_settings[score_display][]" value="criteria" 
                <?php checked(in_array('criteria', $display)); ?>>
            Show Individual Criteria Scores
        </label><br>
        <label>
            <input type="checkbox" name="aura_badge_settings[score_display][]" value="total" 
                <?php checked(in_array('total', $display)); ?>>
            Show Total Score
        </label><br>
        <label>
            <input type="checkbox" name="aura_badge_settings[score_display][]" value="photographer" 
                <?php checked(in_array('photographer', $display)); ?>>
            Show Photographer Name
        </label>
        <?php
    }

    public function add_settings_page() {
        add_submenu_page(
            'edit.php?post_type=aura_contest',
            'Badge Settings',
            'Badge Settings',
            'manage_options',
            'aura_badge_settings',
            array($this, 'render_settings_page')
        );
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h2>Aura Award Badge Settings</h2>
            <form method="post" action="options.php">
                <?php
                settings_fields('aura_badge_options');
                do_settings_sections('aura_badge_settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
    public function render_size_field() {
    $options = get_option('aura_badge_settings');
    $size = isset($options['badge_size']) ? $options['badge_size'] : 'medium';
    ?>
    <select name="aura_badge_settings[badge_size]">
        <option value="small" <?php selected($size, 'small'); ?>>Small (200px)</option>
        <option value="medium" <?php selected($size, 'medium'); ?>>Medium (350px)</option>
        <option value="large" <?php selected($size, 'large'); ?>>Large (500px)</option>
    </select>
    <?php
}

public function render_style_field() {
    $options = get_option('aura_badge_settings');
    $style = isset($options['badge_style']) ? $options['badge_style'] : 'classic';
    ?>
    <select name="aura_badge_settings[badge_style]">
        <option value="classic" <?php selected($style, 'classic'); ?>>Classic</option>
        <option value="modern" <?php selected($style, 'modern'); ?>>Modern</option>
        <option value="minimal" <?php selected($style, 'minimal'); ?>>Minimal</option>
    </select>
    <p class="description">Choose the visual style for award badges</p>
    <?php
}
    
}
