<?php
class AuraCertificateGenerator {
    private $tcpdf;
    
    public function __construct() {
        require_once AURA_AWARD_PATH . 'vendor/tecnickcom/tcpdf/tcpdf.php';
        $this->tcpdf = new TCPDF('L', 'mm', 'A4', true, 'UTF-8');
    }

    public function generate_certificate($entry_id) {
        $entry = AuraDBHandler::get_instance()->get_entry_with_judgment($entry_id);
        
        $this->tcpdf->SetCreator('Aura Award');
        $this->tcpdf->SetAuthor('Aura Award System');
        $this->tcpdf->SetTitle('Award Certificate');
        
        $this->tcpdf->AddPage();
        $this->add_certificate_background();
        $this->add_certificate_content($entry);
        
        return $this->tcpdf->Output('certificate.pdf', 'S');
    }

    private function add_certificate_content($entry) {
        $this->tcpdf->SetFont('helvetica', '', 30);
        $this->tcpdf->Cell(0, 20, 'Certificate of Achievement', 0, 1, 'C');
        
        $this->tcpdf->SetFont('helvetica', '', 20);
        $this->tcpdf->Cell(0, 15, 'This certifies that', 0, 1, 'C');
        
        $this->tcpdf->SetFont('helvetica', 'B', 24);
        $this->tcpdf->Cell(0, 15, $entry->photographer_name, 0, 1, 'C');
        
        $this->tcpdf->SetFont('helvetica', '', 20);
        $this->tcpdf->Cell(0, 15, "has been awarded", 0, 1, 'C');
        
        $this->tcpdf->SetFont('helvetica', 'B', 28);
        $this->tcpdf->Cell(0, 15, ucfirst($entry->award_level) . ' Award', 0, 1, 'C');
    }
}
