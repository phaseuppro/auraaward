<?php
class AuraContestManager {
    private $db;

    public function __construct() {
        $this->db = AuraDBHandler::get_instance();
        add_action('admin_menu', array($this, 'add_menu_pages'));
        add_action('admin_post_create_contest', array($this, 'handle_contest_creation'));
        add_action('admin_post_update_contest', array($this, 'handle_contest_update'));
    }

    public function add_menu_pages() {
        add_menu_page(
            'Aura Award', 
            'Aura Award',
            'manage_options',
            'aura-award',
            array($this, 'render_main_page'),
            'dashicons-awards',
            30
        );

        add_submenu_page(
            'aura-award',
            'Add New Contest',
            'Add New Contest', 
            'manage_options',
            'aura-new-contest',
            array($this, 'render_new_contest_page')
        );

        add_submenu_page(
            'aura-award',
            'Judging Panel',
            'Judging Panel',
            'manage_options',
            'aura-judging',
            array($this, 'render_judging_page')
        );
    }

    public function render_main_page() {
        $contests = $this->db->get_all_contests();
        include AURA_AWARD_PATH . 'templates/admin/contests-overview.php';
    }
}

// Shortcode handler class
class AuraShortcodes {
    public static function init() {
        add_shortcode('aura_submission_form', array(__CLASS__, 'submission_form'));
        add_shortcode('aura_gallery', array(__CLASS__, 'contest_gallery'));
    }

    public static function submission_form($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0
        ), $atts);

        if (!$atts['contest_id']) {
            return '<p>Contest ID is required</p>';
        }

        ob_start();
        include AURA_AWARD_PATH . 'templates/frontend/submission-form.php';
        return ob_get_clean();
    }

    public static function contest_gallery($atts) {
        $atts = shortcode_atts(array(
            'contest_id' => 0,
            'display' => 'grid',
            'limit' => 12
        ), $atts);

        ob_start();
        include AURA_AWARD_PATH . 'templates/frontend/gallery-display.php';
        return ob_get_clean();
    }
}

// Initialize shortcodes
AuraShortcodes::init();