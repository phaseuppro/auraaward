<?php

class AuraDBHandler {
    private static $instance = null;
    private $wpdb;

    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
public function add_badge_position_column() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'aura_entries';
    
    $wpdb->query("ALTER TABLE $table_name ADD COLUMN badge_position VARCHAR(20) DEFAULT 'top-right' AFTER award_level");
}


    public function create_tables() {
        $charset_collate = $this->wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->wpdb->prefix}aura_entries (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            photo_url varchar(255) NOT NULL,
            title varchar(100) NOT NULL,
            photographer_name varchar(100) NOT NULL,
            light_score int(11) DEFAULT 0,
            pose_score int(11) DEFAULT 0,
            idea_score int(11) DEFAULT 0,
            emotion_score int(11) DEFAULT 0,
            materials_score int(11) DEFAULT 0,
            colors_score int(11) DEFAULT 0,
            total_score int(11) DEFAULT 0,
            jury_points int(11) DEFAULT 0,
            award_level varchar(20) DEFAULT NULL,
            badge_position varchar(20) DEFAULT 'top-right',
            processed_image_id bigint(20) DEFAULT NULL,
            status varchar(20) DEFAULT 'pending',
            submission_date datetime DEFAULT CURRENT_TIMESTAMP,
            judged_date datetime DEFAULT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function get_entries($contest_id = null) {
    $query = "
        SELECT e.*, 
               COALESCE(u.display_name, 'Anonymous') as display_name
        FROM {$this->wpdb->prefix}aura_entries e 
        LEFT JOIN {$this->wpdb->users} u ON e.user_id = u.ID 
        WHERE (e.status = 'pending' OR e.status = 'judged')";
    
    if ($contest_id) {
        $query .= $this->wpdb->prepare(" AND e.contest_id = %d", $contest_id);
    }
    
    $query .= " ORDER BY e.submission_date DESC";
    
    return $this->wpdb->get_results($query);
}

    public function update_entry_judgment($entry_id, $scores, $result) {
        return $this->wpdb->update(
            $this->wpdb->prefix . 'aura_entries',
            array(
                'light_score' => $scores['light'],
                'pose_score' => $scores['pose'],
                'idea_score' => $scores['idea'],
                'emotion_score' => $scores['emotion'],
                'materials_score' => $scores['materials'],
                'colors_score' => $scores['colors'],
                'total_score' => $result['total_score'],
                'jury_points' => $result['jury_points'],
                'award_level' => $result['award_level'],
                'badge_position' => $result['badge_position'],
                'status' => 'judged',
                'judged_date' => current_time('mysql')
            ),
            array('id' => $entry_id)
        );
    }
public function update_database_structure() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'aura_entries';
    
    $wpdb->query("
        ALTER TABLE {$table_name} 
        ADD COLUMN IF NOT EXISTS badge_position VARCHAR(20) 
        DEFAULT 'top-right' 
        AFTER award_level
    ");
}
    public function get_next_pending_entry() {
        return $this->wpdb->get_row("
            SELECT e.*, u.display_name 
            FROM {$this->wpdb->prefix}aura_entries e 
            LEFT JOIN {$this->wpdb->users} u ON e.user_id = u.ID 
            WHERE e.status = 'pending' 
            ORDER BY e.submission_date ASC 
            LIMIT 1
        ");
    }

    public function get_entry_with_scores($entry_id) {
        return $this->wpdb->get_row($this->wpdb->prepare("
            SELECT * FROM {$this->wpdb->prefix}aura_entries 
            WHERE id = %d
        ", $entry_id));
    }
}
