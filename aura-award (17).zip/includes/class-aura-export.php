<?php
class AuraExport {
    public function export_contest_results($contest_id) {
        $entries = AuraDBHandler::get_instance()->get_contest_results($contest_id);
        
        $filename = 'aura-contest-results-' . $contest_id . '.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        fputcsv($output, array(
            'Entry ID',
            'Photographer',
            'Title',
            'Submission Date',
            'Award Level',
            'Total Score',
            'Composition Score',
            'Technical Score',
            'Creativity Score',
            'Impact Score'
        ));
        
        foreach ($entries as $entry) {
            fputcsv($output, array(
                $entry->id,
                $entry->photographer_name,
                $entry->title,
                $entry->submission_date,
                $entry->award_level,
                $entry->total_score,
                $entry->composition_score,
                $entry->technical_score,
                $entry->creativity_score,
                $entry->impact_score
            ));
        }
        
        fclose($output);
        exit;
    }
}
