<?php

class AuraGalleryDisplay {
    private $db_handler;
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct($db_handler = null) {
        $this->db_handler = $db_handler;
        add_shortcode('aura_judged_gallery', array($this, 'render_gallery'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_gallery_assets'));
    }

    public function enqueue_gallery_assets() {
        wp_enqueue_style('aura-gallery', AURA_AWARD_URL . 'assets/css/gallery.css');
        wp_enqueue_script('aura-gallery', AURA_AWARD_URL . 'assets/js/gallery.js', array('jquery'), null, true);
        
        $custom_css = "
            .aura-gallery {
                max-width: 1200px;
                margin: 0 auto;
            }
            
            .gallery-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                gap: 15px;
                padding: 15px;
            }
            
            .gallery-item {
                background: #fff;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                overflow: hidden;
                transition: transform 0.3s ease;
            }
            
            .gallery-item:hover {
                transform: translateY(-5px);
            }
            
            .gallery-item img {
                width: 100%;
                height: 250px;
                object-fit: cover;
            }
            
            .image-details {
                padding: 12px;
            }
            
            .image-details h3 {
                margin: 0 0 6px;
                font-size: 16px;
                line-height: 1.3;
            }
            
            .photographer-info {
                font-size: 14px;
                color: #666;
                margin-bottom: 8px;
            }
            
            .award-badge {
                display: inline-block;
                padding: 4px 8px;
                border-radius: 4px;
                margin-top: 6px;
                font-weight: bold;
                background: #f0f0f0;
            }
            
            .jury-points {
                margin-top: 6px;
                color: #666;
                font-size: 14px;
            }
            
            .gallery-filters {
                text-align: center;
                margin: 15px 0;
            }
            
            .award-filter {
                padding: 8px 16px;
                border-radius: 4px;
                border: 1px solid #ddd;
                font-size: 14px;
            }
            
            @media (max-width: 768px) {
                .gallery-grid {
                    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                    gap: 10px;
                    padding: 10px;
                }
                
                .gallery-item img {
                    height: 200px;
                }
            }
        ";
        
        wp_add_inline_style('aura-gallery', $custom_css);
    }

    public function render_gallery($atts) {
        global $wpdb;
        
        $atts = shortcode_atts(array(
            'award_level' => 'all',
            'limit' => -1,
            'orderby' => 'submission_date',
            'order' => 'DESC'
        ), $atts);

        $query = "SELECT e.*, u.display_name, u.user_nicename as photographer_name 
                 FROM {$wpdb->prefix}aura_entries e 
                 LEFT JOIN {$wpdb->users} u ON e.user_id = u.ID 
                 WHERE e.status = 'judged'";
        
        if ($atts['award_level'] !== 'all') {
            $query .= $wpdb->prepare(" AND e.award_level = %s", $atts['award_level']);
        }
        
        $query .= " ORDER BY e.{$atts['orderby']} {$atts['order']}";
        
        if ($atts['limit'] > 0) {
            $query .= " LIMIT " . intval($atts['limit']);
        }
        
        $entries = $wpdb->get_results($query);
        
        ob_start();
        ?>
        <div class="aura-gallery">
            <div class="gallery-filters">
                <select class="award-filter">
                    <option value="all">All Awards</option>
                    <option value="platinum">Platinum</option>
                    <option value="gold">Gold</option>
                    <option value="silver">Silver</option>
                    <option value="bronze">Bronze</option>
                </select>
            </div>
            
            <div class="gallery-grid">
                <?php foreach ($entries as $entry): ?>
                    <div class="gallery-item" data-award="<?php echo esc_attr($entry->award_level); ?>">
                        <img src="<?php echo esc_url($entry->photo_url); ?>" alt="<?php echo esc_attr($entry->title); ?>">
                        <div class="image-details">
                            <h3><?php echo esc_html($entry->title); ?></h3>
                            <div class="photographer-info">
                                By <?php echo esc_html($entry->photographer_name ?: $entry->display_name); ?>
                            </div>
                            <div class="award-badge <?php echo esc_attr($entry->award_level); ?>">
                                <?php echo esc_html(ucfirst($entry->award_level)); ?>
                            </div>
                            <div class="jury-points">
                                Jury Points: <?php echo esc_html($entry->jury_points); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
