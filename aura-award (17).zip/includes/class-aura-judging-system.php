<?php

class AuraJudgingSystem {
    private static $instance = null;
    private $db;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function calculate_jury_points($total_score) {
        $jury_points = round(($total_score / 60) * 100);
        return max(0, min(100, $jury_points));
    }

    public function determine_award_level($jury_points) {
        if ($jury_points >= 90) return 'platinum';
        if ($jury_points >= 80) return 'gold';
        if ($jury_points >= 70) return 'silver';
        if ($jury_points >= 60) return 'bronze';
        return 'participant';
    }

    public function process_judgment($entry_id, $scores, $badge_position) {
    global $wpdb;
    
    // Validate all required scores are present
    $required_criteria = ['light', 'pose', 'idea', 'emotion', 'materials', 'colors'];
    foreach ($required_criteria as $criteria) {
        if (!isset($scores[$criteria])) {
            return new WP_Error('missing_criteria', "Missing score for {$criteria}");
        }
    }
    
    $total_score = array_sum($scores);
    $jury_points = $this->calculate_jury_points($total_score);
    $award_level = $this->determine_award_level($jury_points);
    
    $update_data = array(
        'light_score' => $scores['light'],
        'pose_score' => $scores['pose'],
        'idea_score' => $scores['idea'],
        'emotion_score' => $scores['emotion'],
        'materials_score' => $scores['materials'],
        'colors_score' => $scores['colors'],
        'total_score' => $total_score,
        'jury_points' => $jury_points,
        'award_level' => $award_level,
        'badge_position' => $badge_position,
        'status' => 'judged',
        'judged_date' => current_time('mysql')
    );
    
    $result = $wpdb->update(
        $wpdb->prefix . 'aura_entries',
        $update_data,
        array('id' => $entry_id)
    );

    if ($result) {
        // Process badge after successful judgment
$badge_processor = AuraBadgeProcessor::get_instance();
$processed_image_id = $badge_processor->process_judged_image($entry_id, $badge_position);

// Add the error logging here
if (is_wp_error($processed_image_id)) {
    error_log('Badge processing failed: ' . $processed_image_id->get_error_message());
}

if (!is_wp_error($processed_image_id)) {
    $wpdb->update(
        $wpdb->prefix . 'aura_entries',
        array('processed_image_id' => $processed_image_id),
        array('id' => $entry_id)
    );
}
    }
    
    return array(
        'success' => true,
        'message' => 'Judgment saved successfully',
        'award_level' => $award_level,
        'jury_points' => $jury_points,
        'processed_image_id' => $processed_image_id
    );
}

    private function process_badge_after_judgment($entry_id, $award_level, $badge_position) {
        $badge_processor = AuraBadgeProcessor::get_instance();
        $badge_settings = get_option('aura_badge_settings', array(
            'badge_position' => $badge_position,
            'score_display' => array('criteria', 'total', 'photographer')
        ));

        $attachment_id = $badge_processor->process_judged_image($entry_id, $badge_position);
        
        if (!is_wp_error($attachment_id)) {
            global $wpdb;
            $wpdb->update(
                $wpdb->prefix . 'aura_entries',
                array(
                    'processed_image_id' => $attachment_id,
                    'badge_position' => $badge_position
                ),
                array('id' => $entry_id)
            );
            
            do_action('aura_badge_processed', $entry_id, $attachment_id, $badge_position);
        }

        return $attachment_id;
    }

    public function handle_judgment() {
    check_ajax_referer('aura_judging', 'nonce');
    
    if (!current_user_can('judge_entries')) {
        wp_send_json_error('Insufficient permissions');
    }

    $scores = array(
        'light' => intval($_POST['scores']['light']),
        'pose' => intval($_POST['scores']['pose']),
        'idea' => intval($_POST['scores']['idea']),
        'emotion' => intval($_POST['scores']['emotion']),
        'materials' => intval($_POST['scores']['materials']),
        'colors' => intval($_POST['scores']['colors'])
    );

    $badge_position = sanitize_text_field($_POST['badge_position']);
    $entry_id = intval($_POST['entry_id']);
    
    $result = $this->process_judgment($entry_id, $scores, $badge_position);
    
    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }

    do_action('aura_judgment_saved', $entry_id, $result['award_level'], $badge_position);
    wp_send_json_success($result);
}

    public function load_next_entry() {
        check_ajax_referer('aura_judging', 'nonce');
        $next_entry = $this->db->get_next_pending_entry();
        wp_send_json_success(['entry' => $next_entry]);
    }
}
