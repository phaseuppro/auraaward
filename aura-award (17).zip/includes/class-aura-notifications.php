<?php

class AuraNotifications {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('aura_judgment_saved', array($this, 'send_award_notification'), 10, 2);
    }

    public function send_award_notification($entry_id, $award_level) {
        global $wpdb;
        
        $entry = $wpdb->get_row($wpdb->prepare("
            SELECT e.*, u.user_email, u.display_name 
            FROM {$wpdb->prefix}aura_entries e 
            JOIN {$wpdb->users} u ON e.user_id = u.ID 
            WHERE e.id = %d", 
            $entry_id
        ));

        if (!$entry) return false;

        $subject = sprintf('Congratulations! Your photo received a %s award', ucfirst($award_level));
        
        $message = $this->get_award_email_template([
            'photographer_name' => $entry->display_name,
            'photo_title' => $entry->title,
            'award_level' => $award_level,
            'jury_points' => $entry->jury_points,
            'view_url' => get_permalink($entry->attachment_id)
        ]);

        return wp_mail(
            $entry->user_email, 
            $subject, 
            $message, 
            ['Content-Type: text/html; charset=UTF-8']
        );
    }

    private function get_award_email_template($data) {
        ob_start();
        include AURA_AWARD_PATH . 'templates/emails/award-notification.php';
        return ob_get_clean();
    }
}
