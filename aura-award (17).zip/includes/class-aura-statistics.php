<?php
class AuraStatistics {
    private $db;
    
    public function __construct() {
        $this->db = new AuraDBHandler();
    }
    
    public function get_contest_stats($contest_id) {
        return array(
            'total_entries' => $this->get_total_entries($contest_id),
            'judged_entries' => $this->get_judged_entries($contest_id),
            'pending_entries' => $this->get_pending_entries($contest_id)
        );
    }
    
    private function get_total_entries($contest_id) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}aura_entries WHERE contest_id = %d",
            $contest_id
        ));
    }
    
    private function get_judged_entries($contest_id) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}aura_entries e 
            JOIN {$wpdb->prefix}aura_judgments j ON e.id = j.entry_id 
            WHERE e.contest_id = %d",
            $contest_id
        ));
    }
    
    private function get_pending_entries($contest_id) {
        global $wpdb;
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}aura_entries e 
            LEFT JOIN {$wpdb->prefix}aura_judgments j ON e.id = j.entry_id 
            WHERE e.contest_id = %d AND j.id IS NULL",
            $contest_id
        ));
    }
}