<?php
class AuraSubmissionHandler {
    public function handle_submission() {
    error_log('Starting submission handler');
    
    try {
        check_ajax_referer('aura_award_submission', 'nonce');
        
        if (!is_user_logged_in()) {
            error_log('User not logged in');
            wp_send_json_error('Login required');
        }

        error_log('Processing upload');
        $submission_data = $this->validate_and_process_upload();
        
        if (is_wp_error($submission_data)) {
            error_log('Validation error: ' . $submission_data->get_error_message());
            wp_send_json_error($submission_data->get_error_message());
        }

        error_log('Saving entry');
        $entry_id = $this->save_entry($submission_data);
        
        if ($entry_id) {
            error_log('Entry saved successfully: ' . $entry_id);
            wp_send_json_success([
                'message' => 'Entry submitted successfully',
                'entry_id' => $entry_id
            ]);
        }
    } catch (Exception $e) {
        error_log('Submission error: ' . $e->getMessage());
        wp_send_json_error('Submission failed: ' . $e->getMessage());
    }
}

private function save_entry($data) {
    global $wpdb;
    
    error_log('Attempting to save entry to database');
    
    $result = $wpdb->insert(
        $wpdb->prefix . 'aura_entries',
        array(
            'contest_id' => $data['contest_id'],
            'user_id' => $data['user_id'],
            'title' => $data['title'],
            'photo_url' => $data['photo_url'],
            'status' => 'pending'
        ),
        array('%d', '%d', '%s', '%s', '%s')
    );
    
    if ($result === false) {
        error_log('Database error: ' . $wpdb->last_error);
        return false;
    }
    
    return $wpdb->insert_id;
}


    private function validate_and_process_upload() {
    $file = $_FILES['photo'];
    $image_info = getimagesize($file['tmp_name']);
    
    // Get the longest side
    $longest_side = max($image_info[0], $image_info[1]);
    error_log('Longest side: ' . $longest_side . 'px');
    
    // File size in MB
    $file_size_mb = $file['size'] / (1024 * 1024);
    
    // Size validation rules
    if ($longest_side < 2048) {
        return new WP_Error('image_size', 'Image must be at least 2048px on the longest side');
    }
    
    if ($longest_side > 4000) {
        return new WP_Error('image_size', 'Image must not exceed 4000px on the longest side');
    }
    
    // File size validation rules
    if ($file_size_mb < 1) {
        return new WP_Error('file_size', 'File size must be at least 1MB');
    }
    
    if ($file_size_mb > 5) {
        return new WP_Error('file_size', 'File size must not exceed 5MB');
    }

    // First handle the upload
    $upload = wp_handle_upload($file, ['test_form' => false]);
    
    // Then create the attachment
    $attachment = array(
        'post_mime_type' => $upload['type'],
        'post_title' => sanitize_text_field($_POST['title']),
        'post_content' => '',
        'post_status' => 'inherit'
    );

    $attach_id = wp_insert_attachment($attachment, $upload['file']);
    wp_update_attachment_metadata($attach_id, wp_generate_attachment_metadata($attach_id, $upload['file']));
    
    return [
        'photo_url' => $upload['url'],
        'title' => sanitize_text_field($_POST['title']),
        'contest_id' => intval($_POST['contest_id']),
        'user_id' => get_current_user_id(),
        'attachment_id' => $attach_id
    ];
}


}
