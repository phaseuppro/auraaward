<?php
if (!class_exists('WP_List_Table')) {
    require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}

class Aura_Submissions_List extends WP_List_Table {
    
    public function __construct() {
        parent::__construct([
            'singular' => 'submission',
            'plural'   => 'submissions',
            'ajax'     => false
        ]);
    }

    public function prepare_items() {
        global $wpdb;
        error_log('Preparing items with detailed query');
        
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = array();
        $this->_column_headers = array($columns, $hidden, $sortable);
        
        $per_page = 20;
        $current_page = $this->get_pagenum();
        
        $this->items = $wpdb->get_results($wpdb->prepare("
            SELECT 
                e.*,
                u.display_name,
                u.user_email,
                c.title as contest_title
            FROM {$wpdb->prefix}aura_entries e
            LEFT JOIN {$wpdb->users} u ON e.user_id = u.ID
            LEFT JOIN {$wpdb->prefix}aura_contests c ON e.contest_id = c.id
            ORDER BY e.submission_date DESC
            LIMIT %d OFFSET %d
        ", $per_page, ($current_page - 1) * $per_page));
        
        error_log('Query results: ' . print_r($this->items, true));
    }
    
    // Rest of your existing methods remain the same
    public function get_columns() {
        return [
            'photo' => 'Photo',
            'photographer' => 'Photographer',
            'submission_date' => 'Submitted',
            'status' => 'Status',
            'scores' => 'Scores',
            'jury_points' => 'Jury Points',
            'badge' => 'Badge',
            'actions' => 'Actions'
        ];
    }
    
    private function calculate_jury_points($star_points) {
        return round(($star_points * 100) / 60);
    }
    
    private function get_badge_level($jury_points) {
        if ($jury_points >= 91) return 'Platinum';
        if ($jury_points >= 71) return 'Gold';
        if ($jury_points >= 51) return 'Silver';
        if ($jury_points >= 30) return 'Bronze';
        if ($jury_points >= 1) return 'Participant';
        return '';
    }
    
    public function column_default($item, $column_name) {
    switch ($column_name) {
        case 'photo':
            return '<img src="' . esc_url($item->photo_url) . '" style="max-width: 100px; height: auto;" />';
        
        case 'photographer':
            return esc_html($item->display_name);
        
        case 'submission_date':
            return date('Y-m-d H:i', strtotime($item->submission_date));
        
        case 'status':
            return esc_html(ucfirst($item->status));
        
        case 'scores':
            return sprintf(
                'Light: %d<br>Pose: %d<br>Idea: %d<br>Emotion: %d<br>Materials: %d<br>Colors: %d<br>Total: %d',
                $item->light_score,
                $item->pose_score,
                $item->idea_score,
                $item->emotion_score,
                $item->materials_score,
                $item->colors_score,
                $item->total_score
            );
        
        case 'jury_points':
            $jury_points = round(($item->total_score * 100) / 60);
            return $jury_points;
        
        case 'badge':
            $jury_points = round(($item->total_score * 100) / 60);
            if ($jury_points >= 91) return 'Platinum';
            if ($jury_points >= 71) return 'Gold';
            if ($jury_points >= 51) return 'Silver';
            if ($jury_points >= 30) return 'Bronze';
            return 'Participant';
        
        case 'actions':
            $actions = [];
            if ($item->status !== 'judged') {
                $actions[] = sprintf(
                    '<a href="%s">Judge</a>',
                    admin_url('admin.php?page=aura-award-judging&entry_id=' . $item->id)
                );
            }
            return implode(' | ', $actions);
    }
    return '';
}

}
