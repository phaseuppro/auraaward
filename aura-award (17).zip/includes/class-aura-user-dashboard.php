<?php
class AuraUserDashboard {
    private $db;
    
    public function __construct() {
        $this->db = AuraDBHandler::get_instance();
        add_shortcode('aura_user_dashboard', array($this, 'render_dashboard'));
    }

    public function render_dashboard() {
        if (!is_user_logged_in()) {
            return '<p>Please log in to view your dashboard.</p>';
        }

        $user_id = get_current_user_id();
        $user_entries = $this->db->get_user_entries($user_id);
        $user_awards = $this->get_user_awards($user_id);

        ob_start();
        include AURA_AWARD_PATH . 'templates/frontend/user-dashboard.php';
        return ob_get_clean();
    }

    private function get_user_awards($user_id) {
        return $this->db->get_user_awards($user_id);
    }
}