<div class="wrap">
    <h1>Aura Award Badge Settings</h1>
    
    <form method="post" action="options.php" class="aura-badge-settings">
        <?php settings_fields('aura_badge_options'); ?>
        <?php do_settings_sections('aura_badge_settings'); ?>
        
        <div class="badge-preview">
            <h2>Badge Preview</h2>
            <div class="preview-container">
                <img src="<?php echo AURA_AWARD_URL; ?>assets/images/sample-photo.jpg" alt="Sample photo">
                <div class="badge-overlay" data-position="<?php echo esc_attr(get_option('aura_badge_position', 'top-right')); ?>">
                    <img src="<?php echo AURA_AWARD_URL; ?>assets/badges/gold.png" alt="Sample badge">
                </div>
            </div>
        </div>

        <table class="form-table">
            <tr>
                <th scope="row">Badge Size</th>
                <td>
                    <select name="aura_badge_settings[size]">
                        <option value="small" <?php selected(get_option('aura_badge_size'), 'small'); ?>>Small (200px)</option>
                        <option value="medium" <?php selected(get_option('aura_badge_size'), 'medium'); ?>>Medium (350px)</option>
                        <option value="large" <?php selected(get_option('aura_badge_size'), 'large'); ?>>Large (500px)</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row">Score Display</th>
                <td>
                    <fieldset>
                        <label>
                            <input type="checkbox" name="aura_badge_settings[show_scores]" value="1" <?php checked(get_option('aura_badge_show_scores'), 1); ?>>
                            Show individual scores
                        </label><br>
                        <label>
                            <input type="checkbox" name="aura_badge_settings[show_total]" value="1" <?php checked(get_option('aura_badge_show_total'), 1); ?>>
                            Show total score
                        </label>
                    </fieldset>
                </td>
            </tr>
            <tr>
                <th scope="row">Badge Style</th>
                <td>
                    <select name="aura_badge_settings[style]">
                        <option value="classic" <?php selected(get_option('aura_badge_style'), 'classic'); ?>>Classic</option>
                        <option value="modern" <?php selected(get_option('aura_badge_style'), 'modern'); ?>>Modern</option>
                        <option value="minimal" <?php selected(get_option('aura_badge_style'), 'minimal'); ?>>Minimal</option>
                    </select>
                </td>
            </tr>
        </table>
        
        <?php submit_button('Save Badge Settings'); ?>
    </form>
</div>
