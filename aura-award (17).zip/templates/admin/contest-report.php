<?php if (!defined('ABSPATH')) exit; ?>

<div class="aura-statistics-dashboard">
    <div class="stats-overview">
        <div class="stat-card total-entries">
            <h3>Total Entries</h3>
            <div class="stat-value"><?php echo esc_html($stats['total_entries']); ?></div>
        </div>
        
        <div class="stat-card award-distribution">
            <h3>Award Distribution</h3>
            <div class="award-chart">
                <?php foreach ($stats['award_distribution'] as $level => $count): ?>
                    <div class="award-bar <?php echo esc_attr($level); ?>">
                        <span class="count"><?php echo esc_html($count); ?></span>
                        <span class="label"><?php echo esc_html(ucfirst($level)); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="stat-card top-entries">
            <h3>Top Scoring Entries</h3>
            <ul>
                <?php foreach ($stats['top_scoring_entries'] as $entry): ?>
                    <li>
                        <span class="score"><?php echo esc_html($entry->total_score); ?></span>
                        <span class="title"><?php echo esc_html($entry->title); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <div class="submission-timeline">
        <canvas id="submissionChart"></canvas>
    </div>

    <div class="judging-progress">
        <div class="progress-bar">
            <div class="progress" style="width: <?php echo esc_attr($stats['judging_progress']); ?>%">
                <?php echo esc_html($stats['judging_progress']); ?>% Judged
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('submissionChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_keys($stats['daily_submissions'])); ?>,
            datasets: [{
                label: 'Daily Submissions',
                data: <?php echo json_encode(array_values($stats['daily_submissions'])); ?>,
                borderColor: '#2271b1',
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
});
</script>
