<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap">
    <h1 class="wp-heading-inline">Aura Award Contests</h1>
    <a href="<?php echo admin_url('admin.php?page=aura-new-contest'); ?>" class="page-title-action">Add New Contest</a>

    <div class="aura-contests-grid">
        <?php foreach ($contests as $contest): ?>
            <div class="contest-card">
                <h2><?php echo esc_html($contest->title); ?></h2>
                <div class="contest-meta">
                    <span class="date">
                        <?php echo esc_html(date('M d, Y', strtotime($contest->start_date))); ?> - 
                        <?php echo esc_html(date('M d, Y', strtotime($contest->end_date))); ?>
                    </span>
                    <span class="status <?php echo esc_attr($contest->status); ?>">
                        <?php echo esc_html(ucfirst($contest->status)); ?>
                    </span>
                </div>
                <div class="contest-actions">
                    <a href="<?php echo admin_url('admin.php?page=aura-judging&contest=' . $contest->id); ?>" class="button">Judge Entries</a>
                    <a href="<?php echo admin_url('admin.php?page=aura-award&action=edit&id=' . $contest->id); ?>" class="button">Edit</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>