<?php if (!defined('ABSPATH')) exit; ?>

<div class="aura-judging-interface">
    <?php if ($entry): ?>
        <div class="judging-lightbox">
            <div class="judging-content">
                <!-- Left: Photo Display -->
                <div class="photo-section">
                    <div class="photo-frame">
                        <img src="<?php echo esc_url($entry->photo_url); ?>" alt="<?php echo esc_attr($entry->title); ?>">
                    </div>
                    <h2 class="photo-title"><?php echo esc_html($entry->title); ?></h2>
                </div>

                <!-- Right: Judging Panel -->
                <div class="judging-panel">
                    <div class="award-preview">
                        <div class="medal-icon"></div>
                        <div class="award-level">Judging in progress...</div>
                        <div class="jury-points-display">0 Jury Points</div>
                    </div>

                    <form id="judging-form">
                        <?php wp_nonce_field('aura_judging', 'judging_nonce'); ?>
                        <input type="hidden" name="entry_id" value="<?php echo esc_attr($entry->id); ?>">
                        
                        <?php
                        $criteria = [
                            'light' => ['Light Quality', 'Evaluate the use and control of light'],
                            'pose' => ['Pose & Composition', 'Assess the arrangement and positioning'],
                            'idea' => ['Creative Concept', 'Rate the originality and creativity'],
                            'emotion' => ['Emotional Impact', 'Judge the emotional connection'],
                            'materials' => ['Technical Quality', 'Evaluate the technical execution'],
                            'colors' => ['Color Harmony', 'Assess the color balance']
                        ];
                        // Initialize scores from entry data if they exist
$saved_scores = [
    'light' => $entry->light_score ?? 0,
    'pose' => $entry->pose_score ?? 0,
    'idea' => $entry->idea_score ?? 0,
    'emotion' => $entry->emotion_score ?? 0,
    'materials' => $entry->materials_score ?? 0,
    'colors' => $entry->colors_score ?? 0
];

                        foreach ($criteria as $key => $details): ?>
                            <div class="criteria-card">
    <div class="criteria-header">
        <h3><?php echo esc_html($details[0]); ?></h3>
        <span class="score-display"><?php echo $saved_scores[$key]; ?></span>
    </div>
    <div class="star-rating" data-criteria="<?php echo esc_attr($key); ?>">
        <?php for($i = 1; $i <= 10; $i++): 
            $is_active = $i <= $saved_scores[$key] ? 'active' : '';
        ?>
            <span class="star <?php echo $is_active; ?>" data-value="<?php echo $i; ?>">★</span>
        <?php endfor; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div class="scoring-summary">
                            <div class="total-stars">
                                <span class="label">Total Stars:</span>
                                <span id="total-points">0</span>/60
                            </div>
                            <div class="badge-position-selector">
    <h3>Badge Position</h3>
    <select name="badge_position" id="badge_position">
        <option value="top-left">Top Left</option>
        <option value="top-right">Top Right</option>
        <option value="bottom-left">Bottom Left</option>
        <option value="bottom-right">Bottom Right</option>
    </select>
    <div class="position-preview">
        <img src="<?php echo esc_url($entry->photo_url); ?>" alt="Preview">
        <div class="badge-overlay" data-position="top-right"></div>
    </div>
</div>
                            <div class="jury-points">
                                <span class="label">Jury Points:</span>
                                <span id="jury-points">0</span>/100
                            </div>
                        </div>

                        <div class="action-buttons">
                            <button type="submit" class="button button-primary">Submit Judgment</button>
                            <button type="button" class="button skip-entry">Skip Entry</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="no-entries-message">
            <h2>No Entries to Judge</h2>
            <p>There are currently no pending entries requiring judgment.</p>
        </div>
    <?php endif; ?>
</div>
