<?php if (!defined('ABSPATH')) exit; ?>

<div class="wrap">
    <h1>Add New Contest</h1>
    
    <form method="post" action="" class="aura-new-contest-form">
        <?php wp_nonce_field('create_contest', 'contest_nonce'); ?>
        
        <div class="form-field">
            <label for="contest_title">Contest Title</label>
            <input type="text" id="contest_title" name="contest_title" required>
        </div>
        
        <div class="form-field">
            <label for="contest_description">Description</label>
            <textarea id="contest_description" name="contest_description" rows="5" required></textarea>
        </div>
        
        <div class="form-field-group">
            <div class="form-field">
                <label for="start_date">Start Date</label>
                <input type="datetime-local" id="start_date" name="start_date" required>
            </div>
            
            <div class="form-field">
                <label for="end_date">End Date</label>
                <input type="datetime-local" id="end_date" name="end_date" required>
            </div>
        </div>
        
        <div class="form-field">
            <label for="contest_status">Status</label>
            <select id="contest_status" name="contest_status">
                <option value="draft">Draft</option>
                <option value="published">Published</option>
                <option value="closed">Closed</option>
            </select>
        </div>
        
        <div class="form-submit">
            <button type="submit" class="button button-primary">Create Contest</button>
            <a href="<?php echo admin_url('admin.php?page=aura-award'); ?>" class="button">Cancel</a>
        </div>
    </form>
</div>
