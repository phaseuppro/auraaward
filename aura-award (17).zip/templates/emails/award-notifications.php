<!DOCTYPE html>
<html>
<head>
    <style>
        .award-email {
            max-width: 600px;
            margin: 0 auto;
            font-family: Arial, sans-serif;
            color: #333;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .header {
            background: linear-gradient(135deg, #1a2a6c, #b21f1f);
            color: #fff;
            padding: 30px;
            text-align: center;
            border-radius: 8px 8px 0 0;
        }
        .award-badge {
            margin: 30px 0;
            text-align: center;
        }
        .award-badge img {
            width: 150px;
            height: auto;
        }
        .score-breakdown {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 5px;
            margin: 20px;
        }
        .score-item {
            display: flex;
            justify-content: space-between;
            margin: 12px 0;
            padding: 8px 0;
            border-bottom: 2px solid #e9ecef;
            font-size: 16px;
        }
        .total-score {
            background: #2c3e50;
            color: #fff;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin-top: 20px;
            font-size: 1.3em;
            font-weight: bold;
        }
        .view-button {
            display: block;
            text-align: center;
            margin: 30px 0;
        }
        .view-button a {
            background: #2c3e50;
            color: #fff;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 25px;
            font-weight: bold;
            transition: background 0.3s ease;
        }
        .view-button a:hover {
            background: #34495e;
        }
        <?php if ($data['award_level'] === 'gold'): ?>
        .header { background: linear-gradient(135deg, #FFD700, #FFA500); }
        <?php elseif ($data['award_level'] === 'silver'): ?>
        .header { background: linear-gradient(135deg, #C0C0C0, #808080); }
        <?php elseif ($data['award_level'] === 'bronze'): ?>
        .header { background: linear-gradient(135deg, #CD7F32, #8B4513); }
        <?php endif; ?>
    </style>
</head>
<body>
    <div class="award-email">
        <div class="header">
            <h1>Congratulations, <?php echo esc_html($data['photographer_name']); ?>!</h1>
            <h2>Your photo "<?php echo esc_html($data['photo_title']); ?>" has received a <?php echo esc_html(ucfirst($data['award_level'])); ?> Award</h2>
        </div>

        <div class="score-breakdown">
            <h3>Judging Results:</h3>
            <div class="score-item">
                <span>🌟 Light Quality</span>
                <span><?php echo esc_html($data['scores']['light']); ?>/10</span>
            </div>
            <div class="score-item">
                <span>📐 Pose & Composition</span>
                <span><?php echo esc_html($data['scores']['pose']); ?>/10</span>
            </div>
            <div class="score-item">
                <span>💡 Creative Idea</span>
                <span><?php echo esc_html($data['scores']['idea']); ?>/10</span>
            </div>
            <div class="score-item">
                <span>❤️ Emotional Impact</span>
                <span><?php echo esc_html($data['scores']['emotion']); ?>/10</span>
            </div>
            <div class="score-item">
                <span>🎨 Materials & Texture</span>
                <span><?php echo esc_html($data['scores']['materials']); ?>/10</span>
            </div>
            <div class="score-item">
                <span>🎯 Color Harmony</span>
                <span><?php echo esc_html($data['scores']['colors']); ?>/10</span>
            </div>
            <div class="total-score">
                Final Score: <?php echo esc_html($data['scores']['total']); ?>/60
            </div>
        </div>

        <div class="view-button">
            <a href="<?php echo esc_url($data['view_url']); ?>">View Your Award-Winning Photo</a>
        </div>
    </div>
</body>
</html>
