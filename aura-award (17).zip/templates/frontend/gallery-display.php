<?php
$db_handler = AuraDBHandler::get_instance();
$entries = $db_handler->get_entries();
?>

<div class="aura-gallery">
    <div class="gallery-grid">
        <?php foreach ($entries as $entry): ?>
            <div class="gallery-item <?php echo $entry->status === 'judged' ? 'judged' : 'pending'; ?>">
                <div class="image-container">
                    <img src="<?php echo esc_url($entry->photo_url); ?>" alt="<?php echo esc_attr($entry->title); ?>">
                    <?php if ($entry->status === 'judged' && $entry->award_level): ?>
                        <img class="award-badge <?php echo esc_attr($entry->badge_position); ?>"
                             src="<?php echo AURA_AWARD_URL . 'assets/images/badges/' . esc_attr($entry->award_level) . '.png'; ?>"
                             alt="<?php echo esc_attr($entry->award_level); ?>">
                    <?php endif; ?>
                </div>
                <div class="image-details">
                    <h3><?php echo esc_html($entry->title); ?></h3>
                    <div class="photographer-info">
                        By <?php echo esc_html($entry->display_name); ?>
                    </div>
                    <?php if ($entry->status === 'judged'): ?>
                        <div class="award-info">
                            <div class="award-badge <?php echo esc_attr($entry->award_level); ?>">
                                <?php echo esc_html(ucfirst($entry->award_level)); ?>
                            </div>
                            <div class="jury-points">
                                Points: <?php echo esc_html($entry->jury_points); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
