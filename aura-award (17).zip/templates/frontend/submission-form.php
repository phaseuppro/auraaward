<?php
if (!is_user_logged_in()) {
    return '<p>Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to submit your entry.</p>';
}
if (!defined('ABSPATH')) exit;
?>
<div class="aura-submission-form" id="aura-submission-form">
    <form method="post" enctype="multipart/form-data">
        <?php wp_nonce_field('aura_award_submission', 'aura_nonce'); ?>
        <input type="hidden" name="contest_id" value="<?php echo esc_attr($contest_id); ?>">
        
        <div class="form-group">
            <label for="photo-title">Photo Title</label>
            <input type="text" id="photo-title" name="title" required>
        </div>

        <div class="form-group">
            <label for="photo-upload">Upload Photo</label>
            <input type="file" id="photo-upload" name="photo" accept="image/*" required>
            <div class="upload-requirements">
                Minimum size: 2048px on longest side
                Maximum size: 5MB
                Formats: JPG, PNG
            </div>
        </div>

        <button type="submit" class="aura-submit-btn">Submit Entry</button>
    </form>
</div>